

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try {
		Dbconn db= new Dbconn();
		String name=request.getParameter("name");
		int ph=Integer.parseInt(request.getParameter("ph"));
		String n=request.getParameter("usr");
		String p=request.getParameter("pswd");
		int i;
		
			i = db.insert(name, n, p, ph);
			if(i==1) {
				
				RequestDispatcher rd=request.getRequestDispatcher("/Login.html");
				
				rd.forward(request, response);
			}
			else {
				out.print("There is some error");
				RequestDispatcher rd=request.getRequestDispatcher("/Register.html");
				rd.include(request, response);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
